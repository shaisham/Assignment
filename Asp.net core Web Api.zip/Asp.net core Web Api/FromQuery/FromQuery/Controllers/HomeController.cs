﻿using Microsoft.AspNetCore.Mvc;

namespace FromQuery.Controllers
{
    [ApiController]
    
    public class HomeController : ControllerBase

    {
        [HttpGet]
        [Route("api/{controller}/{action}")]
        public IActionResult Index(string val1, string val2, string val3)
        {
            return Ok("Hello"+val1+ val2+ val3);
        }
    }
}
