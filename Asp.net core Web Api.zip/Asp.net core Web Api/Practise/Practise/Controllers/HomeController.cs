﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Practise.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class HomeController : ControllerBase
    {
        [HttpGet]
        public string Index()
        {
            return "Hello, My name is shameer.......";
        }
        [HttpGet("BookInfo")]
        public Book BookInfo() //method 
        {
            Book MyBook = new Book() //Object intializer
            {
                Title = "shameer",
                Genre = "Horror"

            };
            return MyBook;
        }
        [HttpGet("AllBooks")]
        public List<Book> AllBooks() //method 
        {
            List<Book> MyBook = new List<Book>()// Object intializer
            {
                new Book() { Title = "shameer", Genre ="Horror"},
                new Book() { Title ="Jungle", Genre="Comedy"},
                new Book() { Title ="Avatar", Genre="Adventure"}
            };
            return MyBook;
        }
        [HttpGet("BookInfoById")]
        public ActionResult<string> BookInfoById(string Id) //method 
        {
            //Connect to database and fetch the Book Based On ID
            if (string.IsNullOrEmpty(Id))
            {
                return BadRequest("Bad Request");
            }
            else if (Id == "0") // Data does not present in DB
            {
                return "Not Found";
            }
            else
            {
                Book MyBook = new Book() //Object intializer
                {
                    Title = "shameer",
                    Genre = "Horror"

                };
                return Ok (MyBook);
            }
        }

        public class Book// class 
        {
            public string Title { get; set; }
            public string Genre { get; set; }
                
        }
    }
}
