﻿using Microsoft.AspNetCore.Mvc;

namespace Routing.Controllers
{
    [ApiController]
    public class HomeController : ControllerBase
    {
        //Without Parameters

        //[HttpGet]
        //[Route("Employees")]
        //public IActionResult Employees()
        //{
        //    return Ok("Hello");
        //}

        //change the route
        [HttpGet]
        [Route("api/{controller}/{action}")]
        public IActionResult Employees()
        {
            return Ok("Hello");
        }

        //With Single Parameters
        [HttpGet]
        [Route("api/{controller}/{action}/{id}")]
        public IActionResult EmployeesById(string id )
        {
            return Ok("Hello...."+ id);
        }


        //With multiple Parameters
        [HttpGet]
        [Route("api/{controller}/{action}/{id}/dept/{deptid}")]
        public IActionResult EmployeesSalaryById(string id, string deptid )
        {
            return Ok("Hello...." + id+ "hahahah.........."+ deptid);
        }

        //using queryString

        [HttpGet]
        [Route("api/{controller}/{action}")]
        public IActionResult EmployeeSearch(string id, string deptid)
        {
            return Ok("Hello...." + id + "hahahah.........." + deptid);
        }
    }
}
