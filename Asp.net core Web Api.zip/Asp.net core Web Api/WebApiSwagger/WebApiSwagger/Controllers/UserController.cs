﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using WebApiSwagger.Models;

namespace WebApiSwagger.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly UserDbContext _context;

        public UserController(UserDbContext db)
        {
            _context = db;
        }

        [HttpGet]
        public async Task<ActionResult> Get()
        {
            return Ok(await _context.Users.ToListAsync());
        }
        [HttpPost]
        public async Task<ActionResult> AddBook(User user)
        {
            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            return Ok(await _context.Users.ToListAsync());
        }
        [HttpGet("{id}")]
        public async Task<ActionResult> Get(int id)
        {
            var libr = await _context.Users.FindAsync(id);
            if (libr == null)
            {
                return BadRequest("Books Not Found");
            }
            return Ok(libr);
        }
        [HttpPut("{id}")]
        public async Task<ActionResult> Update(User request)
        {
            var dbLibr = await _context.Users.FindAsync(request.id);
            if (dbLibr == null)
            {
                return BadRequest("No Teacher");
            }
            dbLibr.Name = request.Name;
            dbLibr.Age = request.Age;
            await _context.SaveChangesAsync();
            return Ok(await _context.Users.ToListAsync());
        }
        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            var dbLibr = await _context.Users.FindAsync(id);
            if (dbLibr == null)
            {
                return BadRequest("Books Not Found");
            }
            _context.Users.Remove(dbLibr);
            await _context.SaveChangesAsync();
            return Ok(await _context.Users.ToListAsync());
        }
    }
}

