﻿using System.ComponentModel.DataAnnotations;

namespace WebApiSwagger.Models
{
    public class User
    {
        [Key]
        public int id { get; set; }
        public  int Name { get; set; }
        public int Age { get; set; }
    }
}
