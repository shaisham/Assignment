﻿using Microsoft.AspNetCore.Mvc;
using MyDotNetCore.Data;
using MyDotNetCore.Models;

namespace MyDotNetCore.Controllers
{
    public class ProductController : Controller
    {
        private readonly ProductDbContext productDbContext;
        public ProductController(ProductDbContext db)
        {
            productDbContext = db;
        }
        public IActionResult Index()
        {
            IEnumerable<Product> product = productDbContext.Product;
            return View(product);
        }
    }
    }
