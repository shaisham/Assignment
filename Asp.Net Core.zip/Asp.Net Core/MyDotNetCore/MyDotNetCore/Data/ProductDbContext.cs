﻿
using Microsoft.EntityFrameworkCore;
using MyDotNetCore.Models;

namespace MyDotNetCore.Data
   
{
    public class ProductDbContext: DbContext
    {
        public ProductDbContext(DbContextOptions<ProductDbContext> options) : base(options)
        {

        }
        public DbSet<Product> Product { set; get; }
    }


}